# Local Docker Registry

This project runs a local Docker Registry secured with a username and password for purpose of bootstrapping DecentHousing.

## Quick Start Guide

### 1. Configure Credentials
Copy `.env.example` file to `.env` file and customize the credentials as needed:
* `REGISTRY_USER` (username)
* `REGISTRY_PASSWORD` (password)
* `REGISTRY_PORT` (registry port, defaults to `5050`)

### 2. Start the Registry
Run the following command in your terminal from this directory:
```bash
docker compose up -d
```

> If you modify `.env`, just run this command again. The registry will automatically restart and apply the new credentials.

### 3. Stop the Registry
To stop the registry:
```bash
docker compose down
```
